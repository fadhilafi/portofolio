from selenium.webdriver.common.by import By

class Locators:
    # Button Hitung
    HITUNG_BUTTON = (By.ID, "hitung")

    # Input field
    INPUT_ANGKA = (By.ID, "input")

    #Result locator
    RESULT_LOCATOR = (By.ID, "result")
