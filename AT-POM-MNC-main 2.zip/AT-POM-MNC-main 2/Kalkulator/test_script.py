from Kalkulator.TestData import TestData
from Kalkulator.Locators import Locators
from Kalkulator.Pages import Hitung
import time
from BaseTest import BaseTest

class testHitung(BaseTest):
    #Test case 1
    def test_data_1(self):
        self.test_data1 = Hitung(self.driver)
        self.test_data1.data_1()
        #assert
        compare_data_1 = self.test_data1.get_text(Locators.RESULT_LOCATOR)
        self.assertEqual(TestData.RESULT_DATA_1, compare_data_1)

    # Test case 1
    def test_data_2(self):
        self.test_data2 = Hitung(self.driver)
        self.test_data2.data_2()
        #assert
        compare_data_2 =self.test_data2.get_text(Locators.RESULT_LOCATOR)
        self.assertEqual(TestData.RESULT_DATA_2,compare_data_2)
        time.sleep(3)

    # Test case 1
    def test_data_3(self):
        self.test_data3 = Hitung(self.driver)
        self.test_data3.data_3()
        #assert
        compare_data_3 = self.test_data3.get_text(Locators.RESULT_LOCATOR)
        self.assertEqual(TestData.RESULT_DATA_3, compare_data_3)
        time.sleep(3)

    # Test case 1
    def test_data_4(self):
        self.test_data4 = Hitung(self.driver)
        self.test_data4.data_4()
        #assert
        compare_data_4 = self.test_data4.get_text(Locators.RESULT_LOCATOR)
        self.assertEqual(TestData.RESULT_DATA_4, compare_data_4)
        time.sleep(3)

    # Test case 1
    def test_data_5(self):
        self.test_data5 = Hitung(self.driver)
        self.test_data5.data_5()
        #assert
        compare_data_5 = self.test_data5.get_text(Locators.RESULT_LOCATOR)
        self.assertEqual(TestData.RESULT_DATA_5, compare_data_5)
        time.sleep(3)

    # Test case nomer 3
    def test_data_6(self):
        self.test_data6 = Hitung(self.driver)
        self.test_data6.data_6()
        # assert
        compare_data_6 = self.test_data6.get_text(Locators.RESULT_LOCATOR)
        self.assertEqual(TestData.RESULT_DATA_6, compare_data_6)
        time.sleep(3)

    # Test case 5
    def test_data_7(self):
        self.test_data7 = Hitung(self.driver)
        self.test_data7.data_7()
        # assert
        compare_data_7 = self.test_data7.get_text(Locators.RESULT_LOCATOR)
        self.assertEqual(TestData.RESULT_DATA_7, compare_data_7)
        time.sleep(5)

    # Test case 2
    def test_data_8(self):
        self.test_data8 = Hitung(self.driver)
        self.test_data8.data_8()
        #assert
        compare_data_8 = self.test_data8.get_text(Locators.RESULT_LOCATOR)
        self.assertEqual(TestData.RESULT_DATA_8, compare_data_8)
        time.sleep(3)

    # Test case 4
    def test_data_9(self):
        self.test_data9 = Hitung(self.driver)
        self.test_data9.data_9()
        #assert
        compare_data_9 = self.test_data9.get_text(Locators.RESULT_LOCATOR)
        self.assertEqual(TestData.RESULT_DATA_9, compare_data_9)
        time.sleep(3)

