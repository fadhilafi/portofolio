from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time


class BasePage:
    def __init__(self, driver):
        self.driver = driver
        self.action = ActionChains(driver)

    def enter_hour(self, field, select, hour):
        self.click(field)
        # self.click(box)
        self.click(select)
        # hh = self.driver.find_element(*select)
        hh = self.driver.find_element(*select)
        hh.send_keys(hour)
        hh.send_keys(Keys.ENTER)
        time.sleep(2)

    def enter_minutes(self, locator, minutes):
        self.click(locator)
        mm = self.driver.find_element(*locator)
        mm.send_keys(minutes)
        mm.send_keys(Keys.ENTER)
        time.sleep(2)

    def alert_js(self):
        WebDriverWait(self.driver, 3000).until(
            EC.alert_is_present()
        )

    # function input data
    def enter_text(self, locator, enter):
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(locator)
        ).send_keys(enter)

    def enter_time(self, locator, text):
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(locator)
        ).send_keys(text)

    # function click Locator
    def click(self, locator):
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(locator)
        ).click()

    # function delete data
    def clear_text(self, locator):
        WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(locator)
        ).clear()

    # def backspace(self, locator):
    #     WebDriverWait(self.driver, 10).until(
    #         EC.element_to_be_clickable(locator)
    #     ).send_keys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE))

    def backspace(self, locator):
        self.click(locator)
        dl = self.driver.find_element(*locator)
        dl.send_keys(Keys.CONTROL, "a")
        dl.send_keys(Keys.BACK_SPACE)
        # dl.send_keys(Keys.ENTER)





    # function get text
    def get_text(self, locator):
        return WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(locator)
        ).text

    def get_toast(self, locator):
        get_toast = self.driver.find_element(locator)
        return get_toast.get_attribut("innerHTML")

    # function check element visible
    def is_visible(self, locator):
        try:
            element = WebDriverWait(self.driver, 10).until(
                EC.visibility_of_element_located(locator))
            return bool(element)
        except TimeoutException:
            return False

    # function select single drop down by index
    def select_single_dropdown_by_index(self, locator, item):
        dropdown = Select(self.driver.find_element_by_id(locator))
        dropdown.select_by_index(item)

    # function select multi drop down aa
    def select_single_dropdown_by_class(self, locator, item):
        dropdown = Select(self.driver.find_element_by_class(locator))
        dropdown.select_by_index(item)

    # function select dropdown
    def select_dropdown_by_value(self, locator, item):
        dropdown = Select(self.driver.find_element_by_id(locator))
        dropdown.select_by_value(item)

    def select_dropdown_by_xpath(self, locator, item):
        dropdown = Select(self.driver.find_element_by_xpath(locator))
        dropdown.select_by_visible_text(item)

    def select_dropdown_by_visible_text(self, locator, item):
        dropdown = Select(self.driver.find_element_by_id(locator))
        dropdown.select_by_visible_text(item)
        time.sleep(2)

    def select_multiple_list(self, locator, item):
        dropdown = Select(self.driver.find_element_by_id(locator))
        dropdown.select_by_visible_text(item)

    # by me
    def select_drowdown_by_css(self):
        dropwodn = Select(WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "div.vc-time-select"))))
        dropwodn.select_by_visible_text("09")

    def select_dd_time(self, locator):
        dd = Select(self.driver.find_element_by_xpath(locator))
        dd.select_by_value('1')

    # select = Select(
    #     WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "select.select[name='fruits']"))))
    # select.select_by_value("2")

    # function hover
    def move_element_to(self, locator):
        hover = self.driver.find_element_by_xpath(locator)
        self.action.move_to_element(hover).perform()

    # function click js alert
    def alert_click(self, locator):
        self.driver.find_element_by_xpath(locator).click()
        jsalert = self.driver.switch_to.alert.accept()
        return jsalert.get_attribute("validationMessage")

    def alert_js_validation(self):
        email_input = self.driver.find_element_by_id("email")
        return email_input.get_attribute("validationMessage")

    def date_picker(self, boxyear, selectyear, years):
        year = self.driver.find_element(*boxyear)
        select_year = year.find_elements(*selectyear)
        for i in select_year:
            # print(i.text)
            if i.text == years:
                i.click()
                break
        time.sleep(1)

    def day_picker(self, selectday, days):
        select_day = self.driver.find_elements(*selectday)
        for day in select_day:
            # print(day.text)
            if day.text == days:
                day.click()
                break

    def time_picker(self, selectday, teks):
        select_day = self.driver.find_elements(*selectday)
        select_day.send_keys(teks)
        # for day in select_day:
        #     print(day.text)
        #     if day.text == days:
        #         day.click()
        #         break
        time.sleep(1)



    # def time_picker(self, boxtime, selecttime, time):
    #     times = self.driver.find_element(*boxtime)
    #     select_times = times.find_element(*selecttime)
    #     for i in select_times:
    #         if i.text == time:
    #             i.click()
    #             break

    def set_time(self):
        select = Select(WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, ".vc-time-select"))))
        select.select_by_index(2)

    # Jan
    # Feb
    # Mar
    # Apr
    # May
    # Jun
    # Jul
    # Aug
    # Sep
    # Oct
    # Nov
    # Dec
    # def set_time(self, locator, index):
    #     select_fr = Select(self.driver.find_element_by_xpath(*locator))
    #     select_fr.select_by_index(index).



    def select_values_from_dropdown(self, dropdown, values):
        print(len(dropdown))
        for ele in dropdown:
            print(ele.text)
            if ele.text == values:
                ele.click()
                break

    def single_dd(self, locator, field, value):
        field = self.driver.find_element(*locator)
        field.send_keys(value)
        field.send_keys(Keys.DOWN)
        field.send_keys(Keys.ENTER)

    def enter_del_input(self, locator, input):
        self.click(locator)
        time.sleep(3)
        pp = self.driver.find_element(*locator)
        pp.send_keys(Keys.CONTROL, 'a')
        pp.send_keys(Keys.BACK_SPACE)
        pp.send_keys(input)
        pp.send_keys(Keys.ENTER)






